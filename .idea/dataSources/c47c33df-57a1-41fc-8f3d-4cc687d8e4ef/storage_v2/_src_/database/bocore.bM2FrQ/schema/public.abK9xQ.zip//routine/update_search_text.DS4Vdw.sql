create function update_search_text() returns trigger
    language plpgsql
as
$$
declare
  table_columns holder [];
  current_row holder;
  r RECORD;
  timestamps timestamp [];
  timestamp_strings varchar [];
  strings varchar [];
  dates date [];
  date_strings varchar [];
  times time [];
  time_strings varchar [];
  temp_string  text;
  search_text_value text;
  should_update	bool;
  stop_words	varchar;

begin
  for current_row in
  select
    boc_meta.table_name as table_name,
    boc_attr.atrb_type as attr_type,
    case
    when boc_attr.atrb_type = 'value list' then array_agg( attr_meta.column_name )
    else array_agg( attr_meta.column_name || '::varchar' )
    end as column_names
  from bo_instance i
    left join bo_class_meta boc_meta on	i.bo_class_id = boc_meta.bo_class_id and not boc_meta.is_deleted
    left join bo_class_attribute boc_attr on boc_attr.bo_class_id = i.bo_class_id and not boc_attr.is_deleted
    left join bo_attr_meta attr_meta on	attr_meta.bo_class_attribute_id = boc_attr.id and not attr_meta.is_deleted
  where
    i.id = new.bo_instance_id
    and boc_attr."name" <> 'Name'
  group by
    boc_meta.table_name,
    boc_attr.atrb_type
  loop
    -- collect meta data grouped by attribute type
    table_columns = table_columns || current_row;
  end loop;

  if table_columns is not null then
    foreach current_row in array table_columns
    loop
      if current_row.attr_type = 'value list' then -- concat all value list attributes into array
        execute format(
            'select %s as column_values from %s where bo_instance_id = %s',
            array_to_string(current_row.column_names, ' || '),
            current_row.table_name,
            new.bo_instance_id
        ) into r;

        strings = strings || r.column_values::varchar [];

      elseif current_row.attr_type = 'timestamp' then
        execute format(
            'select array[%s] as column_values from %s where bo_instance_id = %s',
            array_to_string(current_row.column_names, ' ,'),
            current_row.table_name,
            new.bo_instance_id
        ) into timestamps;

      elseif current_row.attr_type = 'date' then
        execute format(
            'select array[%s] as column_values from %s where bo_instance_id = %s',
            array_to_string(current_row.column_names,' ,'),
            current_row.table_name,
            new.bo_instance_id
        ) into dates;

      elseif current_row.attr_type = 'time' then
        execute format(
            'select array[%s] as column_values from %s where bo_instance_id = %s',
            array_to_string(current_row.column_names, ' ,'),
            current_row.table_name,
            new.bo_instance_id
        ) into times;

      else -- collect all other values into array
        execute format(
            'select array[%s] as column_values from %s where bo_instance_id = %s',
            array_to_string(current_row.column_names, ' , '),
            current_row.table_name,
            new.bo_instance_id
        ) into r;

        strings = strings || r.column_values::varchar [];

      end if;
    end loop;
  end if;

  with outer_qry as(
    with qry as(select unnest(dates) elem)
    select to_char(elem, 'YYYY-MM-DD') formatted
    from qry
    union
    select to_char(elem, 'Month Day') formatted
    from qry
  ) select array_agg( formatted ) into date_strings
    from outer_qry;

  with outer_qry as(
    with qry as(select unnest(times) elem)
    select to_char(elem, 'HH24:MM') formatted
    from qry
  ) select array_agg( formatted ) into time_strings
    from outer_qry;

  select ts_created, ts_updated into r from bo_instance where id = new.bo_instance_id;

  timestamps = array_cat(timestamps, array[r.ts_created, r.ts_updated]);

  with outer_qry as(
    with qry as(select unnest(timestamps) elem)
    select to_char(elem, 'YYYY-MM-DD HH24:MM') formatted
    from qry
    union
    select to_char(elem, 'Month Day') formatted
    from qry
  ) select array_agg( formatted ) into timestamp_strings
    from outer_qry;

  select i.id, i."name" as i_name, i.updated_by_user, boc."name" as boc_name, i.tags into r
  from bo_instance i
    left join bo_class boc on boc.id = i.bo_class_id
  where i.id = new.bo_instance_id;

  strings = array_cat(strings, array_cat(ARRAY [r.id, r."i_name", r.updated_by_user, r.boc_name] :: VARCHAR [], r.tags :: VARCHAR []) :: VARCHAR []);

  search_text_value = array_to_string(strings, ' ');

  select coalesce(array_to_string(array_agg(q.elem), '|'), '') as stop_words_combined into r
  from (select json_array_elements_text(value::json) elem from global_params where "name" = 'SEARCH_TEXT_STOP_WORDS') q;
  stop_words = r.stop_words_combined;

  search_text_value = regexp_replace(
      search_text_value,
      '(?:[\s]|^)('||stop_words||')(?=[\s]|$)',
      '',
      'g');

  search_text_value = regexp_replace(
      search_text_value,
      '[!$%^&*()_+|~=`{}\[\]:";''<>?,\/\\]',
      ' ',
      'g');

  temp_string = array_to_string(timestamp_strings, ' ');
  search_text_value = concat(search_text_value, ' ', temp_string);

  temp_string = array_to_string(date_strings, ' ');
  search_text_value = concat(search_text_value, ' ', temp_string);

  temp_string = array_to_string(time_strings, ' ');
  search_text_value = concat(search_text_value, ' ', temp_string);

  raise notice 'search text is [ % ]', search_text_value;

  -- remove duplicates and order alphabetically
  with qry as(
      select
        distinct unnest(
                     string_to_array(search_text_value, ' ')
                 ) elem order by elem
  ) select array_to_string(array_agg(lower(elem)), ' ') into search_text_value
    from qry where elem is not null and elem <> '';

  if new.TG_OP = 'INSERT' then
    should_update = true;
  else
    select i.search_text <> search_text_value into should_update from bo_instance i where i.id = new.bo_instance_id;
  end if;

  if should_update then
    update bo_instance set search_text = search_text_value where id = new.bo_instance_id;
  end if;

  update search_text_update_queue set ts_procesed = now() where id = new.id;

  return NEW;
end;
$$;

alter function update_search_text() owner to bocore;

