create function table_update_notify() returns trigger
    language plpgsql
as
$$
DECLARE
  id    BIGINT;
  name TEXT;
  value TEXT;
BEGIN
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE'
  THEN
    id = NEW.id;
    name = NEW.name;
    value = new.value;
  ELSE
    id = OLD.id;
    name = OLD.name;
    value = OLD.value;
  END IF;
  PERFORM pg_notify('global_params_channel',
                    json_build_object('table', TG_TABLE_NAME, 'type', TG_OP, 'id', id, 'name', name, 'value', value) :: TEXT);
  RETURN NEW;
END;
$$;

alter function table_update_notify() owner to bocore;

