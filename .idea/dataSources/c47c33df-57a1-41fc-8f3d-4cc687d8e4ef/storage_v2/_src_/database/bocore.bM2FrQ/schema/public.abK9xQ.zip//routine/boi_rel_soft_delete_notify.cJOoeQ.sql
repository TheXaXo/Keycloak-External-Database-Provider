create function boi_rel_soft_delete_notify() returns trigger
    language plpgsql
as
$$
DECLARE
  id               BIGINT;
  from_bo_class_id BIGINT;
  to_bo_class_id   BIGINT;

BEGIN
  id = NEW.id;
  from_bo_class_id = NEW.from_bo_class_id;
  to_bo_class_id = NEW.to_bo_class_id;

  PERFORM
  pg_notify('boi_rel_channel',
            json_build_object('id', id, 'from_bo_class_id', from_bo_class_id, 'to_bo_class_id',
                              to_bo_class_id) :: TEXT);
  RETURN NEW;
END;
$$;

alter function boi_rel_soft_delete_notify() owner to bocore;

