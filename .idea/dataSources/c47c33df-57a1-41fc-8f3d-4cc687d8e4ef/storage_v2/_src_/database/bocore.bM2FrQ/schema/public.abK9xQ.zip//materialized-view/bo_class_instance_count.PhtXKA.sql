create materialized view bo_class_instance_count as
SELECT boc.id      AS bocid,
       count(i.id) AS instancescount
FROM bo_class boc
         LEFT JOIN bo_instance i ON i.bo_class_id = boc.id
WHERE NOT boc.is_deleted
  AND NOT i.is_deleted
GROUP BY boc.id
UNION
SELECT '-1'::integer         AS bocid,
       count(bo_instance.id) AS instancescount
FROM bo_instance
WHERE NOT bo_instance.is_deleted;

alter materialized view bo_class_instance_count owner to bocore;

create unique index idx_bo_class_instances_count
    on bo_class_instance_count (bocid);

