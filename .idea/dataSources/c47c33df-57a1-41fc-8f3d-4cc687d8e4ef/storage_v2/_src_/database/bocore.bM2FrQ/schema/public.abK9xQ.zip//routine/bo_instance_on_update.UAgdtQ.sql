create function bo_instance_on_update() returns trigger
    language plpgsql
as
$$
begin
  insert into search_text_update_queue (bo_instance_id, tg_op) values (NEW.id, TG_OP);
  return NEW;
end;
$$;

alter function bo_instance_on_update() owner to bocore;

