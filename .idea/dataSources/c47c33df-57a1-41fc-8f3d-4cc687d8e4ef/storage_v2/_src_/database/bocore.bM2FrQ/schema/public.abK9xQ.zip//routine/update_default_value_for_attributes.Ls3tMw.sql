create function update_default_value_for_attributes() returns void
    language plpgsql
as
$$
DECLARE
  r                     RECORD;
  bo_attribute_value_id BIGINT;
BEGIN
  FOR r IN
    SELECT bam.column_name AS attrib_name, attrib.default_value, meta.table_name
    FROM bo_class_attribute AS attrib
           JOIN bo_class_meta AS meta ON attrib.bo_class_id = meta.bo_class_id
           JOIN bo_attr_meta bam on attrib.id = bam.bo_class_attribute_id
    WHERE attrib.atrb_type != 'value list'
      AND attrib.name != 'Name'
      AND attrib.is_deleted = FALSE
    LOOP
      EXECUTE format(
          'ALTER TABLE %s ALTER COLUMN "%s" SET DEFAULT ''%s''',
          r.table_name,
          r.attrib_name,
          r.default_value
        );

      EXECUTE format(
          'UPDATE %s SET "%s" = DEFAULT WHERE "%s" IS NULL',
          r.table_name,
          r.attrib_name,
          r.attrib_name
        );

      EXECUTE format(
          'ALTER TABLE %s ALTER COLUMN "%s" SET NOT NULL',
          r.table_name,
          r.attrib_name
        );
    END LOOP;
  FOR r IN
    SELECT attrib.id AS bo_class_attribute_id, attrib.bo_class_id
    FROM bo_class_attribute AS attrib
    WHERE attrib.atrb_type = 'value list'
    AND attrib.is_deleted = FALSE
    LOOP
      EXECUTE format(
            'INSERT INTO bo_attribute_value(name, description, bo_class_id, bo_class_attribute_id) ' ||
            'VALUES (''n/a'', ''n/a'', %s, %s)' ||
            'ON CONFLICT DO NOTHING',
            r.bo_class_id,
            r.bo_class_attribute_id
        );

      EXECUTE format(
            'SELECT id FROM bo_attribute_value ' ||
            'WHERE name = ''n/a'' ' ||
            'AND bo_class_id = %s ' ||
            'AND bo_class_attribute_id = %s' ||
            ' LIMIT 1',
            r.bo_class_id,
            r.bo_class_attribute_id
        ) INTO bo_attribute_value_id;

      EXECUTE format(
            'INSERT INTO x_ia_value_list(bo_attribute_value_id, bo_instance_id) ' ||
            '(SELECT %s, boi.id FROM bo_instance AS boi ' ||
            'WHERE boi.bo_class_id = %s ' ||
            'AND (SELECT COUNT(xivl.id) ' ||
            'FROM x_ia_value_list AS xivl ' ||
            'JOIN bo_attribute_value boav ON xivl.bo_attribute_value_id = boav.id ' ||
            'WHERE xivl.bo_instance_id = boi.id ' ||
            'GROUP BY boav.bo_class_attribute_id ' ||
            'HAVING boav.bo_class_attribute_id = %s) ' ||
            'IS NULL) ',
            bo_attribute_value_id,
            r.bo_class_id,
            r.bo_class_attribute_id
        );

      EXECUTE format(
            'UPDATE bo_class_attribute AS bocattrib ' ||
            'SET default_value = %s' ||
            'WHERE bocattrib.id = %s;',
            bo_attribute_value_id,
            r.bo_class_attribute_id
        );
    END LOOP;
END;
$$;

alter function update_default_value_for_attributes() owner to bocore;

