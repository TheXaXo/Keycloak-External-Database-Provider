create function migrate_tags() returns void
    language plpgsql
as
$$
DECLARE
  r RECORD;
BEGIN

  ALTER TABLE bo_instance
    ADD COLUMN tags VARCHAR [];

  ALTER TABLE bo_instance
    ALTER COLUMN tags SET DEFAULT '{}' :: VARCHAR [];

  UPDATE bo_instance
  SET tags = default;

  ALTER TABLE bo_instance
    ALTER COLUMN tags SET NOT NULL;

  FOR r IN
  SELECT
    x.bo_instance_id             AS boi_id,
    array_agg(DISTINCT t."name") AS tags_array
  FROM x_boi_tag x
    LEFT JOIN tag t ON t.id = x.tag_id
  GROUP BY bo_instance_id
  ORDER BY bo_instance_id LOOP
    UPDATE bo_instance
    SET tags = r.tags_array
    WHERE id = r.boi_id;
  END LOOP;

  UPDATE bo_instance
  SET tags = DEFAULT
  WHERE tags IS NULL;
  ALTER TABLE bo_instance
    ALTER COLUMN tags SET NOT NULL;

END;
$$;

alter function migrate_tags() owner to bocore;

