create function boc_attr_change_notify() returns trigger
    language plpgsql
as
$$
DECLARE
  id BIGINT;

BEGIN

  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE'
  THEN
    id = NEW.bo_class_id;
  ELSE
    id = OLD.bo_class_id;
  END IF;


  PERFORM pg_notify('boc_attr_channel',
                    json_build_object('id', id) :: TEXT);
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE'
  THEN
    RETURN NEW;
  ELSE
    RETURN OLD;
  END IF;
END;
$$;

alter function boc_attr_change_notify() owner to bocore;

