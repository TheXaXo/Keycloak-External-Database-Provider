create function boc_rel_change_notify() returns trigger
    language plpgsql
as
$$
DECLARE
  id      BIGINT;
  from_id BIGINT;
  to_id   BIGINT;

BEGIN
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE'
  THEN
    id = NEW.id;
    from_id = NEW.from_bo_class_id;
    to_id = NEW.to_bo_class_id;

  ELSE
    id = OLD.id;
    from_id = OLD.from_bo_class_id;
    to_id = OLD.to_bo_class_id;
  END IF;

  PERFORM pg_notify('boc_rel_channel',
                    json_build_object('id', id, 'from_bo_class_id', from_id, 'to_bo_class_id', to_id) :: TEXT);

  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE'
  THEN
    RETURN NEW;
  ELSE
    RETURN OLD;
  END IF;
END;
$$;

alter function boc_rel_change_notify() owner to bocore;

