create view v_instance(i_id, i_name, is_deleted, c_id, c_name, t_id, t_name) as
SELECT i.id   AS i_id,
       i.name AS i_name,
       i.is_deleted,
       c.id   AS c_id,
       c.name AS c_name,
       t.id   AS t_id,
       t.name AS t_name
FROM bo_instance i,
     bo_class c,
     tenant t
WHERE i.bo_class_id = c.id
  AND i.tenant_id = t.id;

alter table v_instance
    owner to bocore;

