create view v_rel_consistency_check
            (proc_name, r_id, from_instance_id, from_instance_name, from_instance_class_id, from_instance_class_name,
             to_instance_id, to_instance_name, to_instance_class_id, to_instance_class_name, fclass_id, fclass_name,
             tclass_id, tclass_name, brt_id, brt_name, brt_inward, brt_outward, brt_from_class_id, brt_from_class_name,
             brt_to_class_id, brt_to_class_name)
as
SELECT r.updated_by_process AS proc_name,
       r.id                 AS r_id,
       fromv.i_id           AS from_instance_id,
       fromv.i_name         AS from_instance_name,
       fromv.c_id           AS from_instance_class_id,
       fromv.c_name         AS from_instance_class_name,
       tov.i_id             AS to_instance_id,
       tov.i_name           AS to_instance_name,
       tov.c_id             AS to_instance_class_id,
       tov.c_name           AS to_instance_class_name,
       fclass.id            AS fclass_id,
       fclass.name          AS fclass_name,
       tclass.id            AS tclass_id,
       tclass.name          AS tclass_name,
       brt.id               AS brt_id,
       brt.name             AS brt_name,
       brt.inward           AS brt_inward,
       brt.outward          AS brt_outward,
       brt_from_class.id    AS brt_from_class_id,
       brt_from_class.name  AS brt_from_class_name,
       brt_to_class.id      AS brt_to_class_id,
       brt_to_class.name    AS brt_to_class_name
FROM boi_rel r,
     v_instance fromv,
     v_instance tov,
     bo_class fclass,
     bo_class tclass,
     boc_rel_type brt,
     bo_class brt_from_class,
     bo_class brt_to_class
WHERE (r.from_bo_class_id <> fromv.c_id OR r.to_bo_class_id <> tov.c_id OR r.from_bo_class_id <> fromv.c_id OR
       r.to_bo_class_id <> tov.c_id OR brt.from_bo_class_id <> fromv.c_id OR brt.to_bo_class_id <> tov.c_id)
  AND r.from_bo_instance_id = fromv.i_id
  AND r.to_bo_instance_id = tov.i_id
  AND r.from_bo_class_id = fclass.id
  AND r.to_bo_class_id = tclass.id
  AND r.boc_rel_type_id = brt.id
  AND brt.from_bo_class_id = brt_from_class.id
  AND brt.to_bo_class_id = brt_to_class.id;

alter table v_rel_consistency_check
    owner to bocore;

