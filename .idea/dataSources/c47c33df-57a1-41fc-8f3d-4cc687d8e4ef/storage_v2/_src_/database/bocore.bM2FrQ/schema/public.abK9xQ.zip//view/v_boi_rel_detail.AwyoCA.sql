create view v_boi_rel_detail
            (proc_name, boi_rel_id, boi_rel_type_name, from_instance_name, brt_inward_aka_forward_relationship,
             to_instance_name, brt_outward_aka_reverse_relationship, from_instance_class_id,
             from_class_id_in_boi_rel_record, boi_rel_type_from_class_id, from_instance_class_name,
             from_class_name_in_boi_rel_record, boi_rel_type_from_class_name, to_instance_class_id,
             to_class_id_in_boi_rel_record, boi_rel_type_to_class_id, to_instance_class_name,
             to_class_name_in_boi_rel_record, boi_rel_type_to_class_name, boi_rel_type_id, from_instance_id,
             to_instance_id)
as
SELECT r.updated_by_process AS proc_name,
       r.id                 AS boi_rel_id,
       brt.name             AS boi_rel_type_name,
       fromv.i_name         AS from_instance_name,
       brt.inward           AS brt_inward_aka_forward_relationship,
       tov.i_name           AS to_instance_name,
       brt.outward          AS brt_outward_aka_reverse_relationship,
       fromv.c_id           AS from_instance_class_id,
       fclass.id            AS from_class_id_in_boi_rel_record,
       brt_from_class.id    AS boi_rel_type_from_class_id,
       fromv.c_name         AS from_instance_class_name,
       fclass.name          AS from_class_name_in_boi_rel_record,
       brt_from_class.name  AS boi_rel_type_from_class_name,
       tov.c_id             AS to_instance_class_id,
       tclass.id            AS to_class_id_in_boi_rel_record,
       brt_to_class.id      AS boi_rel_type_to_class_id,
       tov.c_name           AS to_instance_class_name,
       tclass.name          AS to_class_name_in_boi_rel_record,
       brt_to_class.name    AS boi_rel_type_to_class_name,
       brt.id               AS boi_rel_type_id,
       fromv.i_id           AS from_instance_id,
       tov.i_id             AS to_instance_id
FROM boi_rel r,
     v_instance fromv,
     v_instance tov,
     bo_class fclass,
     bo_class tclass,
     boc_rel_type brt,
     bo_class brt_from_class,
     bo_class brt_to_class
WHERE r.from_bo_instance_id = fromv.i_id
  AND r.to_bo_instance_id = tov.i_id
  AND r.from_bo_class_id = fclass.id
  AND r.to_bo_class_id = tclass.id
  AND r.boc_rel_type_id = brt.id
  AND brt.from_bo_class_id = brt_from_class.id
  AND brt.to_bo_class_id = brt_to_class.id;

alter table v_boi_rel_detail
    owner to bocore;

